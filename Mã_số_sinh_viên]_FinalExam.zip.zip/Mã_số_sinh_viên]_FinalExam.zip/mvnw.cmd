@REM ----------------------------------------------------------------------------
@REM Maven Wrapper Script untuk Windows (Otomatis Mengunduh Maven Jika Belum Ada)
@REM ----------------------------------------------------------------------------
@echo off
setlocal

set "DIR=%~dp0"
set "MAVEN_VERSION=3.9.6"
set "MAVEN_DIR=%USERPROFILE%\.m2\wrapper\dists\apache-maven-%MAVEN_VERSION%"
set "MAVEN_EXE=%MAVEN_DIR%\apache-maven-%MAVEN_VERSION%\bin\mvn.cmd"

if exist "%MAVEN_EXE%" (
    goto :runMaven
)

echo [INFO] Maven belum terpasang. Mengunduh Apache Maven %MAVEN_VERSION% otomatis...
powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$url = 'https://repo.maven.apache.org/maven2/org/apache/maven/apache-maven/%MAVEN_VERSION%/apache-maven-%MAVEN_VERSION%-bin.zip';" ^
    "$zip = [System.IO.Path]::Combine($env:TEMP, 'apache-maven-%MAVEN_VERSION%-bin.zip');" ^
    "$targetDir = '%MAVEN_DIR%';" ^
    "if (!(Test-Path $targetDir)) { New-Item -ItemType Directory -Force -Path $targetDir | Out-Null };" ^
    "[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12;" ^
    "Invoke-WebRequest -Uri $url -OutFile $zip;" ^
    "Expand-Archive -Path $zip -DestinationPath $targetDir -Force;" ^
    "Remove-Item -Path $zip -Force;"

:runMaven
call "%MAVEN_EXE%" %*
exit /b %ERRORLEVEL%
