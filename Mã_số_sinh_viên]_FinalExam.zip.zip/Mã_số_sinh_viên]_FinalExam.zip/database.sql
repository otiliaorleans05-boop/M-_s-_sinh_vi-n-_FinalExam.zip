-- ==========================================================
-- Database: product_management
-- Skrip SQL untuk inisialisasi Database dan Tabel Products
-- ==========================================================

-- 1. Membuat Database jika belum ada
CREATE DATABASE IF NOT EXISTS `product_management`
    DEFAULT CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

-- Menggunakan database product_management
USE `product_management`;

-- 2. Menghapus tabel jika sudah ada sebelumnya (bersih sebelum inisialisasi)
DROP TABLE IF EXISTS `products`;

-- 3. Membuat Tabel `products`
CREATE TABLE `products` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(255) NOT NULL,
    `price` DOUBLE NOT NULL,
    `quantity` INT NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. Memasukkan 3 Baris Data Sampel Produk (Laptop, Mouse, Keyboard)
INSERT INTO `products` (`id`, `name`, `price`, `quantity`) VALUES
(1, 'Laptop Asus ROG Strix G15', 1299.99, 8),
(2, 'Wireless Mouse Logitech MX Master 3S', 99.50, 25),
(3, 'Mechanical Keyboard Keychron K2', 89.00, 15);
