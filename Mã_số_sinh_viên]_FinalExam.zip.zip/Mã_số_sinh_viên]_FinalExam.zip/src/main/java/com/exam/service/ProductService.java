package com.exam.service;

import com.exam.dao.ProductDAO;
import com.exam.model.Product;

import java.util.List;

/**
 * Service Layer untuk logika bisnis produk (menghubungkan Controller dan DAO).
 */
public class ProductService {

    private final ProductDAO productDAO;

    public ProductService() {
        this.productDAO = new ProductDAO();
    }

    public ProductService(ProductDAO productDAO) {
        this.productDAO = productDAO;
    }

    /**
     * Mengambil daftar semua produk.
     */
    public List<Product> getAllProducts() {
        return productDAO.selectAllProducts();
    }

    /**
     * Mengambil detail satu produk berdasarkan ID.
     */
    public Product getProductById(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID produk tidak valid.");
        }
        return productDAO.selectProductById(id);
    }

    /**
     * Menyimpan produk baru dengan validasi data.
     */
    public void addProduct(Product product) {
        validateProduct(product);
        productDAO.insertProduct(product);
    }

    /**
     * Memperbarui informasi produk dengan validasi data.
     */
    public void updateProduct(Product product) {
        if (product.getId() <= 0) {
            throw new IllegalArgumentException("ID produk tidak valid untuk diperbarui.");
        }
        validateProduct(product);
        productDAO.updateProduct(product);
    }

    /**
     * Menghapus produk berdasarkan ID.
     */
    public void deleteProduct(int id) {
        if (id <= 0) {
            throw new IllegalArgumentException("ID produk tidak valid untuk dihapus.");
        }
        productDAO.deleteProduct(id);
    }

    /**
     * Validasi aturan bisnis dasar untuk produk.
     */
    private void validateProduct(Product product) {
        if (product == null) {
            throw new IllegalArgumentException("Data produk tidak boleh kosong.");
        }
        if (product.getName() == null || product.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Nama produk tidak boleh kosong.");
        }
        if (product.getPrice() < 0) {
            throw new IllegalArgumentException("Harga produk tidak boleh bernilai negatif.");
        }
        if (product.getQuantity() < 0) {
            throw new IllegalArgumentException("Jumlah stok produk tidak boleh bernilai negatif.");
        }
    }
}
