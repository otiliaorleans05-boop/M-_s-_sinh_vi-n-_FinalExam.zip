<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Quản lý sản phẩm</title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --primary-light: #eef2ff;
            --danger: #ef4444;
            --danger-hover: #dc2626;
            --danger-light: #fef2f2;
            --warning: #f59e0b;
            --warning-hover: #d97706;
            --warning-light: #fffbeb;
            --success: #10b981;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --bg-page: #f8fafc;
            --bg-card: #ffffff;
            --border-color: #e2e8f0;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
            --radius-md: 10px;
            --radius-lg: 14px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        body {
            background-color: var(--bg-page);
            color: var(--text-main);
            padding: 32px 16px;
            min-height: 100vh;
        }

        .container {
            max-width: 1050px;
            margin: 0 auto;
        }

        .header-card {
            background: var(--bg-card);
            border-radius: var(--radius-lg);
            padding: 24px 28px;
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 24px;
            flex-wrap: wrap;
            gap: 16px;
        }

        .header-title h1 {
            font-size: 1.5rem;
            font-weight: 700;
            color: #0f172a;
            letter-spacing: -0.02em;
        }

        .header-title p {
            color: var(--text-muted);
            font-size: 0.875rem;
            margin-top: 4px;
        }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            font-size: 0.875rem;
            font-weight: 600;
            padding: 9px 18px;
            border-radius: var(--radius-md);
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background-color: var(--primary);
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(79, 70, 229, 0.25);
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        .btn-edit {
            background-color: var(--warning-light);
            color: #b45309;
            border: 1px solid #fde68a;
            padding: 6px 12px;
            font-size: 0.8rem;
        }

        .btn-edit:hover {
            background-color: #fef3c7;
            color: #92400e;
        }

        .btn-delete {
            background-color: var(--danger-light);
            color: var(--danger);
            border: 1px solid #fecaca;
            padding: 6px 12px;
            font-size: 0.8rem;
        }

        .btn-delete:hover {
            background-color: #fee2e2;
            color: var(--danger-hover);
        }

        .table-card {
            background: var(--bg-card);
            border-radius: var(--radius-lg);
            box-shadow: var(--shadow-sm);
            border: 1px solid var(--border-color);
            overflow: hidden;
        }

        .table-responsive {
            width: 100%;
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            text-align: left;
            font-size: 0.9rem;
        }

        thead {
            background-color: #f1f5f9;
            border-bottom: 1px solid var(--border-color);
        }

        th {
            padding: 14px 20px;
            font-weight: 600;
            color: #475569;
            text-transform: uppercase;
            font-size: 0.75rem;
            letter-spacing: 0.05em;
        }

        tbody tr {
            border-bottom: 1px solid var(--border-color);
            transition: background-color 0.15s ease;
        }

        tbody tr:last-child {
            border-bottom: none;
        }

        tbody tr:hover {
            background-color: #f8fafc;
        }

        td {
            padding: 14px 20px;
            color: var(--text-main);
            vertical-align: middle;
        }

        .badge-id {
            background: #f1f5f9;
            color: #475569;
            padding: 4px 8px;
            border-radius: 6px;
            font-weight: 600;
            font-size: 0.8rem;
        }

        .product-name {
            font-weight: 600;
            color: #0f172a;
        }

        .product-price {
            font-weight: 600;
            color: #047857;
        }

        .badge-quantity {
            display: inline-block;
            padding: 4px 10px;
            border-radius: 9999px;
            font-size: 0.8rem;
            font-weight: 600;
            background-color: #f0fdf4;
            color: #15803d;
            border: 1px solid #bbf7d0;
        }

        .badge-quantity.low-stock {
            background-color: #fff1f2;
            color: #be123c;
            border-color: #fecdd3;
        }

        .action-group {
            display: flex;
            align-items: center;
            gap: 8px;
        }

        .empty-state {
            padding: 50px 20px;
            text-align: center;
            color: var(--text-muted);
        }

        .empty-state svg {
            width: 48px;
            height: 48px;
            margin-bottom: 12px;
            stroke: #cbd5e1;
        }

        @media (max-width: 640px) {
            .header-card {
                flex-direction: column;
                align-items: flex-start;
            }
            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <!-- Header Section -->
    <div class="header-card">
        <div class="header-title">
            <h1>Danh sách sản phẩm</h1>
            <p>Hệ thống quản lý kho &amp; danh mục sản phẩm</p>
        </div>
        <a href="products?action=new" class="btn btn-primary">
            <span>+</span> Thêm sản phẩm mới
        </a>
    </div>

    <!-- Table Section -->
    <div class="table-card">
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th style="width: 80px;">ID</th>
                        <th>Tên sản phẩm</th>
                        <th>Giá</th>
                        <th>Số lượng</th>
                        <th style="width: 160px; text-align: center;">Hành động</th>
                    </tr>
                </thead>
                <tbody>
                    <c:choose>
                        <c:when test="${not empty productList}">
                            <c:forEach items="${productList}" var="p">
                                <tr>
                                    <td>
                                        <span class="badge-id">#${p.id}</span>
                                    </td>
                                    <td>
                                        <span class="product-name">${p.name}</span>
                                    </td>
                                    <td>
                                        <span class="product-price">$${p.price}</span>
                                    </td>
                                    <td>
                                        <span class="badge-quantity ${p.quantity <= 5 ? 'low-stock' : ''}">
                                            ${p.quantity} chiếc
                                        </span>
                                    </td>
                                    <td style="text-align: center;">
                                        <div class="action-group" style="justify-content: center;">
                                            <a href="products?action=edit&id=${p.id}" class="btn btn-edit">Sửa</a>
                                            <a href="products?action=delete&id=${p.id}" class="btn btn-delete" onclick="return confirm('Bạn có chắc chắn muốn xóa sản phẩm này không?');">Xóa</a>
                                        </div>
                                    </td>
                                </tr>
                            </c:forEach>
                        </c:when>
                        <c:otherwise>
                            <tr>
                                <td colspan="5" class="empty-state">
                                    <p>Chưa có sản phẩm nào trong hệ thống.</p>
                                    <a href="products?action=new" style="color: var(--primary); text-decoration: underline; font-size: 0.85rem; margin-top: 6px; display: inline-block;">Thêm sản phẩm đầu tiên</a>
                                </td>
                            </tr>
                        </c:otherwise>
                    </c:choose>
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>
