<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><c:choose><c:when test="${not empty product}">Chỉnh sửa sản phẩm</c:when><c:otherwise>Thêm sản phẩm mới</c:otherwise></c:choose></title>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4f46e5;
            --primary-hover: #4338ca;
            --secondary: #64748b;
            --secondary-hover: #475569;
            --text-main: #1e293b;
            --text-muted: #64748b;
            --bg-page: #f8fafc;
            --bg-card: #ffffff;
            --border-color: #cbd5e1;
            --border-focus: #4f46e5;
            --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
            --radius-md: 10px;
            --radius-lg: 16px;
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
        }

        body {
            background-color: var(--bg-page);
            color: var(--text-main);
            padding: 40px 16px;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-card {
            background: var(--bg-card);
            border-radius: var(--radius-lg);
            padding: 36px 32px;
            width: 100%;
            max-width: 520px;
            box-shadow: var(--shadow-lg);
            border: 1px solid #e2e8f0;
        }

        .form-header {
            margin-bottom: 28px;
            text-align: left;
        }

        .form-header h2 {
            font-size: 1.4rem;
            font-weight: 700;
            color: #0f172a;
            letter-spacing: -0.02em;
        }

        .form-header p {
            font-size: 0.875rem;
            color: var(--text-muted);
            margin-top: 6px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            font-size: 0.85rem;
            font-weight: 600;
            color: #334155;
            margin-bottom: 8px;
        }

        .form-group input {
            width: 100%;
            padding: 11px 14px;
            font-size: 0.925rem;
            border-radius: var(--radius-md);
            border: 1px solid var(--border-color);
            background-color: #fdfdfd;
            color: var(--text-main);
            transition: all 0.2s ease;
            outline: none;
        }

        .form-group input:focus {
            border-color: var(--border-focus);
            background-color: #ffffff;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
        }

        .form-actions {
            display: flex;
            gap: 12px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            font-size: 0.9rem;
            font-weight: 600;
            padding: 12px 20px;
            border-radius: var(--radius-md);
            text-decoration: none;
            transition: all 0.2s ease;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background-color: var(--primary);
            color: #ffffff;
            box-shadow: 0 2px 4px rgba(79, 70, 229, 0.2);
        }

        .btn-primary:hover {
            background-color: var(--primary-hover);
            transform: translateY(-1px);
        }

        .btn-secondary {
            background-color: #f1f5f9;
            color: var(--secondary);
            border: 1px solid #cbd5e1;
        }

        .btn-secondary:hover {
            background-color: #e2e8f0;
            color: var(--secondary-hover);
        }
    </style>
</head>
<body>

<div class="form-card">
    <div class="form-header">
        <h2>
            <c:choose>
                <c:when test="${not empty product}">Chỉnh sửa sản phẩm</c:when>
                <c:otherwise>Thêm sản phẩm mới</c:otherwise>
            </c:choose>
        </h2>
        <p>
            <c:choose>
                <c:when test="${not empty product}">Cập nhật thông tin chi tiết cho mã sản phẩm #${product.id}</c:when>
                <c:otherwise>Điền thông tin bên dưới để tạo sản phẩm mới vào hệ thống</c:otherwise>
            </c:choose>
        </p>
    </div>

    <form action="products" method="POST">
        <!-- Action & Hidden ID Logic -->
        <c:choose>
            <c:when test="${not empty product}">
                <input type="hidden" name="action" value="update" />
                <input type="hidden" name="id" value="${product.id}" />
            </c:when>
            <c:otherwise>
                <input type="hidden" name="action" value="insert" />
            </c:otherwise>
        </c:choose>

        <!-- Tên sản phẩm -->
        <div class="form-group">
            <label for="name">Tên sản phẩm</label>
            <input type="text" id="name" name="name" 
                   value="<c:out value='${product.name}' />" 
                   placeholder="Nhập tên sản phẩm..." required />
        </div>

        <!-- Giá sản phẩm -->
        <div class="form-group">
            <label for="price">Giá sản phẩm ($)</label>
            <input type="number" id="price" name="price" step="0.01" min="0" 
                   value="${product.price}" 
                   placeholder="0.00" required />
        </div>

        <!-- Số lượng -->
        <div class="form-group">
            <label for="quantity">Số lượng tồn kho</label>
            <input type="number" id="quantity" name="quantity" min="0" 
                   value="${product.quantity}" 
                   placeholder="0" required />
        </div>

        <!-- Tombol Aksi -->
        <div class="form-actions">
            <button type="submit" class="btn btn-primary">
                <c:choose>
                    <c:when test="${not empty product}">Cập nhật sản phẩm</c:when>
                    <c:otherwise>Lưu sản phẩm</c:otherwise>
                </c:choose>
            </button>
            <a href="products" class="btn btn-secondary">Hủy bỏ</a>
        </div>
    </form>
</div>

</body>
</html>
