<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%
    // Redirect ke URL "products" (ProductController / Servlet mapping)
    response.sendRedirect(request.getContextPath() + "/products");
%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="refresh" content="0;url=<%=request.getContextPath()%>/products">
    <title>Redirecting...</title>
</head>
<body>
    <p>Mengalihkan ke halaman produk... Jika tidak otomatis, klik <a href="<%=request.getContextPath()%>/products">di sini</a>.</p>
</body>
</html>
